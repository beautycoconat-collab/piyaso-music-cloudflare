import {spawnSync} from 'node:child_process';
import {readFileSync,writeFileSync,existsSync,readdirSync} from 'node:fs';
import {randomBytes,createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
process.chdir(path.dirname(fileURLToPath(import.meta.url)));
const configFile='.setup.json',shards=16;
let state=existsSync(configFile)?JSON.parse(readFileSync(configFile)): {prefix:'piyaso-music-'+randomBytes(3).toString('hex'),ids:[],imported:{}};
const save=()=>writeFileSync(configFile,JSON.stringify(state,null,2));save();
const node=process.execPath,cli=path.resolve('node_modules/wrangler/bin/wrangler.js');
function run(cmd,args,capture=false){const r=spawnSync(cmd,args,{stdio:capture?['inherit','pipe','inherit']:'inherit',encoding:'utf8'});if(r.error)throw r.error;if(r.status!==0)throw Error('Komut başarısız. Sorunu düzelttikten sonra npm run setup komutunu tekrar çalıştır.');return r.stdout||'';}
const wr=(args,capture=false)=>run(node,[cli,...args],capture);
try{
 if(!existsSync(cli))throw Error('Önce npm install çalıştır.');
 let py=process.env.PYTHON||'python3';
 if(spawnSync(py,['--version'],{stdio:'ignore'}).status!==0)py='python';
 if(spawnSync(py,['-c','import sys; assert sys.version_info >= (3,11)'],{stdio:'ignore'}).status!==0)throw Error('Python 3.11 veya üzeri gerekli.');
 console.log('\n1/5 Cloudflare girişi. Tarayıcıdaki hesabını kontrol et.\n');wr(['login']);wr(['whoami']);
 console.log('\n2/5 Resmî MusicBrainz snapshot indiriliyor ve SQL hazırlanıyor. Büyük indirme ve uzun işlem sürebilir.\n');
 run(py,['prepare.py','--shards',String(shards)]);
 const report=JSON.parse(readFileSync('work/report.json'));console.log('Hazır kayıt:',report.tracks,'Doğrudan Spotify bağlantısı:',report.directSpotifyTracks);
 console.log('\n3/5 Yeni ve ayrı 16 katalog veritabanı hazırlanıyor. Mevcut Piyaso veritabanlarına dokunulmaz.\n');
 for(let i=0;i<shards;i++){
  const name=state.prefix+'-'+i.toString().padStart(2,'0');
  if(!state.ids[i]){
   // Random names and persisted IDs isolate this installer from existing app data.
   wr(['d1','create',name]);
   const raw=wr(['d1','list','--json'],true).trim();
   let list;try{list=JSON.parse(raw);}catch{const start=raw.indexOf('['),end=raw.lastIndexOf(']');list=JSON.parse(raw.slice(start,end+1));}
   const db=list.find(d=>d.name===name);if(!db?.uuid)throw Error('Yeni veritabanı kimliği bulunamadı: '+name);
   state.ids[i]={name,id:db.uuid};save();
  }
 }
 const conf={name:state.prefix,main:'src/worker.mjs',compatibility_date:'2026-10-01',vars:{SHARDS:String(shards),ALLOWED_ORIGINS:'https://kiyi-antalya-tur.modesttuna8.chatgpt.site'},d1_databases:state.ids.map((d,i)=>({binding:'MUSIC_'+i,database_name:d.name,database_id:d.id}))};
 writeFileSync('wrangler.json',JSON.stringify(conf,null,2));
 console.log('\n4/5 Katalog Cloudflare D1’e aktarılıyor. Kesilirse aynı komutla devam edebilirsin.\n');
 const files=readdirSync('work/sql').filter(f=>f.endsWith('.sql')).sort((a,b)=>{
  const sa=Number(a.slice(0,2)),sb=Number(b.slice(0,2));return sa-sb||(a.includes('schema')?-1:b.includes('schema')?1:a.localeCompare(b));
 });
 for(const f of files){
  const hash=createHash('sha256').update(readFileSync('work/sql/'+f)).digest('hex');if(state.imported[f]===hash)continue;
  const shard=Number(f.slice(0,2));console.log('Aktarılıyor:',f);
  wr(['d1','execute',state.ids[shard].name,'--remote','--file','work/sql/'+f,'--yes']);state.imported[f]=hash;save();
 }
 console.log('\n5/5 Arama Worker’ı yayınlanıyor.\n');wr(['deploy']);
 console.log('\nKURULUM TAMAMLANDI. Yukarıdaki https://…workers.dev adresini sakla ve ChatGPT’ye gönder.\nÖnce /health, sonra /search?q=Tarkan adresini dene.\nBu paket mevcut Piyaso sitesini otomatik değiştirmez.\n');
}catch(e){console.error('\nDURDU:',e.message);process.exitCode=1;}
