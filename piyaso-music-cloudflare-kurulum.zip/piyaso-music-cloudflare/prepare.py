"""Stream official MusicBrainz JSON snapshots; retain only core metadata fields."""
import argparse, hashlib, json, re, sqlite3, tarfile, unicodedata, urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent
BASE='https://ftp.musicbrainz.org/pub/musicbrainz/data/json-dumps/'
UA='PiyasoCatalogueInstaller/1.0 (local MusicBrainz snapshot importer)'
def get(url):
    return urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':UA}),timeout=120)
def norm(s):
    s=unicodedata.normalize('NFKD',s.lower().replace('ı','i'))
    return ' '.join(''.join(c if c.isalnum() else ' ' for c in s if not unicodedata.combining(c)).split())
def text(s,n=600):
    return str(s or '').replace('\0','')[:n]
def extract(rec):
    mbid=rec.get('id','')
    if not re.fullmatch(r'[0-9a-fA-F-]{36}',mbid): return None
    title=text(rec.get('title'))
    credit=rec.get('artist-credit',[])
    artist=text(''.join(str(c.get('name') or c.get('artist',{}).get('name',''))+str(c.get('joinphrase','')) for c in credit if isinstance(c,dict)))
    if not title or not artist: return None
    spotify=''
    for rel in rec.get('relations',[]):
        if rel.get('ended'): continue
        link=rel.get('url',{}).get('resource','')
        m=re.fullmatch(r'https?://open\.spotify\.com/(?:intl-[a-z]+/)?track/([A-Za-z0-9]{22})(?:\?[^\s]*)?',link)
        if m: spotify='https://open.spotify.com/track/'+m[1];break
    return (mbid,title,artist,spotify,norm(title+' '+artist))
def records(obj,entity):
    if entity=='recording': yield obj
    else:
        for medium in obj.get('media',[]):
            for track in medium.get('tracks',[]):
                rec=dict(track.get('recording') or {})
                if not rec.get('artist-credit'): rec['artist-credit']=track.get('artist-credit') or obj.get('artist-credit',[])
                if not rec.get('title'): rec['title']=track.get('title','')
                yield rec
SQL='INSERT INTO tracks VALUES(?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET spotify=CASE WHEN excluded.spotify<>\'\' THEN excluded.spotify ELSE tracks.spotify END'
def ingest(db,archive,entity):
    count=0
    with tarfile.open(archive,'r|xz') as tar:
        found=False
        for member in tar:
            if member.name.strip('./')!='mbdump/'+entity: continue
            found=True
            for line in tar.extractfile(member):
                if not line.strip():continue
                obj=json.loads(line)
                for rec in records(obj,entity):
                    row=extract(rec)
                    if row:db.execute(SQL,row);count+=1
                if count and count%10000==0:
                    db.commit();print(entity,':',count,'kayıt işlendi',flush=True)
        if not found:raise RuntimeError('Arşivde beklenen mbdump/'+entity+' bulunamadı')
    db.commit();return count
def download(url,path,sha):
    if path.exists() and hashlib.file_digest(path.open('rb'),'sha256').hexdigest()==sha:return
    part=path.with_suffix(path.suffix+'.part')
    start=part.stat().st_size if part.exists() else 0
    req=urllib.request.Request(url,headers={'User-Agent':UA,**({'Range':f'bytes={start}-'} if start else {})})
    with urllib.request.urlopen(req,timeout=120) as response:
        append=start>0 and response.status==206
        with part.open('ab' if append else 'wb') as out:
            total=start if append else 0
            while chunk:=response.read(4*1024*1024):
                out.write(chunk);total+=len(chunk)
                if total//(256*1024*1024)!=(total-len(chunk))//(256*1024*1024):print(path.name,round(total/1024**3,2),'GiB',flush=True)
    with part.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
    if actual!=sha:raise RuntimeError('SHA256 uyuşmadı: '+str(path))
    part.replace(path)
def quote(s):return "'"+s.replace("'","''")+"'"
def export(db,work,shards):
    schema=(ROOT/'schema.sql').read_text()
    handles={};parts=[0]*shards;sizes=[0]*shards;counts=[0]*shards
    out=work/'sql';out.mkdir(exist_ok=True)
    # Never mix output from different snapshots.
    for old in out.glob('*.sql'):old.unlink()
    for i in range(shards):(out/f'{i:02d}-schema.sql').write_text(schema)
    try:
        for row in db.execute('SELECT id,title,artist,spotify,search_text FROM tracks ORDER BY id'):
            shard=int(hashlib.sha256(row[0].encode()).hexdigest()[:8],16)%shards
            if shard not in handles or sizes[shard]>50*1024*1024:
                if shard in handles:handles[shard].close()
                handles[shard]=(out/f'{shard:02d}-data-{parts[shard]:05d}.sql').open('w',encoding='utf-8');parts[shard]+=1;sizes[shard]=0
            line='INSERT INTO tracks VALUES('+','.join(map(quote,row))+') ON CONFLICT(id) DO UPDATE SET title=excluded.title,artist=excluded.artist,spotify=excluded.spotify,search_text=excluded.search_text;\n'
            handles[shard].write(line);sizes[shard]+=len(line.encode());counts[shard]+=1
    finally:
        for h in handles.values():h.close()
    return counts

def main():
    p=argparse.ArgumentParser();p.add_argument('--shards',type=int,default=16);p.add_argument('--archives',type=Path,help='Yerel release.tar.xz ve recording.tar.xz klasörü (indirilenler SHA256 ile doğrulanır)');a=p.parse_args()
    if not 1<=a.shards<=32:raise SystemExit('shards 1–32 olmalı')
    work=ROOT/'work';work.mkdir(exist_ok=True)
    snapshotfile=work/'snapshot.json'
    if snapshotfile.exists():snapshot=json.loads(snapshotfile.read_text())
    else:
        date=get(BASE+'LATEST').read().decode().strip()
        if not re.fullmatch(r'\d{8}-\d{6}',date):raise RuntimeError('Geçersiz snapshot adı')
        sums=get(BASE+date+'/SHA256SUMS').read().decode()
        checks={line.split()[-1].lstrip('*'):line.split()[0] for line in sums.splitlines() if len(line.split())>=2}
        snapshot={'date':date,'checksums':checks};snapshotfile.write_text(json.dumps(snapshot,indent=2))
    archives=a.archives or work
    for entity in ('release','recording'):
        name=entity+'.tar.xz';sha=snapshot['checksums'].get(name)
        if not sha:raise RuntimeError('SHA256 listesinde '+name+' yok')
        path=archives/name
        if a.archives:
            with path.open('rb') as f:actual=hashlib.file_digest(f,'sha256').hexdigest()
            if actual!=sha:raise RuntimeError('Yerel dosya snapshot ile eşleşmiyor: '+name)
        else:download(BASE+snapshot['date']+'/'+name,path,sha)
    db=sqlite3.connect(work/'catalogue.sqlite');db.execute('PRAGMA journal_mode=WAL');db.execute('CREATE TABLE IF NOT EXISTS tracks(id TEXT PRIMARY KEY,title TEXT,artist TEXT,spotify TEXT,search_text TEXT)')
    statefile=work/'ingest-state.json';state=json.loads(statefile.read_text()) if statefile.exists() else {}
    for entity in ('release','recording'):
        if state.get(entity):continue
        print(entity,'arşivi işleniyor…',flush=True);ingest(db,archives/(entity+'.tar.xz'),entity)
        state[entity]=True;statefile.write_text(json.dumps(state))
    counts=export(db,work,a.shards)
    direct=db.execute("SELECT count(*) FROM tracks WHERE spotify<>''").fetchone()[0]
    report={'snapshot':snapshot['date'],'shards':a.shards,'tracks':sum(counts),'directSpotifyTracks':direct,'perShard':counts,'license':'MusicBrainz core data CC0','coverage':'MusicBrainz recording + release snapshots; not all Spotify songs'}
    (work/'report.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2));db.close()
if __name__=='__main__':main()
