import unittest,sqlite3,tarfile,io,json,tempfile
from pathlib import Path
import prepare
class ImportTest(unittest.TestCase):
 def test_release_standalone_idempotence_and_fts(self):
  db=sqlite3.connect(':memory:');db.executescript((prepare.ROOT/'schema.sql').read_text())
  rec={'id':'12345678-1234-1234-1234-123456789012','title':"Şımarık ' test",'artist-credit':[{'name':'Tarkan'}],'relations':[{'url':{'resource':'https://open.spotify.com/track/1234567890123456789012?si=x'}}]}
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'release.tar.xz';data=(json.dumps({'media':[{'tracks':[{'recording':rec}]}]})+'\n').encode()
   with tarfile.open(p,'w:xz') as t:
    info=tarfile.TarInfo('mbdump/release');info.size=len(data);t.addfile(info,io.BytesIO(data))
   prepare.ingest(db,p,'release');prepare.ingest(db,p,'release')
   self.assertEqual(db.execute('SELECT count(*) FROM tracks').fetchone()[0],1)
   self.assertEqual(db.execute("SELECT count(*) FROM tracks_fts WHERE tracks_fts MATCH '\"simarik\"*'").fetchone()[0],1)
   counts=prepare.export(db,Path(d),2);self.assertEqual(sum(counts),1)
   # Replay the exact generated SQL twice against fresh SQLite+FTS5.
   fresh=sqlite3.connect(':memory:');fresh.executescript((prepare.ROOT/'schema.sql').read_text())
   for f in (Path(d)/'sql').glob('*data*.sql'):
    fresh.executescript(f.read_text());fresh.executescript(f.read_text())
   self.assertEqual(fresh.execute('SELECT count(*) FROM tracks_fts').fetchone()[0],1)
 def test_core_whitelist_and_track_link_only(self):
  row=prepare.extract({'id':'12345678-1234-1234-1234-123456789012','title':'Song','artist-credit':[{'artist':{'name':'Artist'}}],'tags':[{'name':'excluded'}],'relations':[{'url':{'resource':'https://open.spotify.com/album/1234567890123456789012'}}]})
  self.assertEqual(row[3],'');self.assertNotIn('excluded',str(row));self.assertEqual(prepare.norm('Şımarık İÇİN'),'simarik icin')
if __name__=='__main__':unittest.main()
