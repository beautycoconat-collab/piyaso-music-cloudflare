CREATE TABLE IF NOT EXISTS tracks(id TEXT PRIMARY KEY,title TEXT NOT NULL,artist TEXT NOT NULL,spotify TEXT NOT NULL DEFAULT '',search_text TEXT NOT NULL);
CREATE VIRTUAL TABLE IF NOT EXISTS tracks_fts USING fts5(search_text,content='tracks',content_rowid='rowid',tokenize='unicode61 remove_diacritics 2');
CREATE TRIGGER IF NOT EXISTS tracks_ai AFTER INSERT ON tracks BEGIN INSERT INTO tracks_fts(rowid,search_text) VALUES(new.rowid,new.search_text); END;
CREATE TRIGGER IF NOT EXISTS tracks_ad AFTER DELETE ON tracks BEGIN INSERT INTO tracks_fts(tracks_fts,rowid,search_text) VALUES('delete',old.rowid,old.search_text); END;
CREATE TRIGGER IF NOT EXISTS tracks_au AFTER UPDATE ON tracks BEGIN INSERT INTO tracks_fts(tracks_fts,rowid,search_text) VALUES('delete',old.rowid,old.search_text); INSERT INTO tracks_fts(rowid,search_text) VALUES(new.rowid,new.search_text); END;
