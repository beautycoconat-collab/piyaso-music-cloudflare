export const normalize=s=>s.toLowerCase().replace(/ı/g,'i').normalize('NFKD').replace(/\p{M}/gu,'').replace(/[^\p{L}\p{N}]+/gu,' ').trim();
export function song(row){
 const direct=/^https:\/\/open\.spotify\.com\/track\/[A-Za-z0-9]{22}$/.test(row.spotify||'');
 return {id:row.id,source:'musicbrainz',title:row.title,artist:row.artist,artwork:'',url:direct?row.spotify:'https://open.spotify.com/search/'+encodeURIComponent(row.title+' '+row.artist),linkType:direct?'track':'search',buttonLabel:direct?'Spotify’da dinle':'Spotify’da bul',musicbrainzUrl:'https://musicbrainz.org/recording/'+row.id};
}
const headers=origin=>({'Content-Type':'application/json; charset=utf-8','Access-Control-Allow-Origin':origin,'Vary':'Origin','X-Content-Type-Options':'nosniff'});
export default {async fetch(request,env,ctx){
 const origin=request.headers.get('Origin')||'', allowed=(env.ALLOWED_ORIGINS||'').split(',').map(x=>x.trim());
 const cors=allowed.includes(origin)?origin:allowed[0]||'';
 const respond=(data,status=200)=>Response.json(data,{status,headers:headers(cors)});
 if(origin&&!allowed.includes(origin))return respond({error:'Origin izinli değil.'},403);
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers:{...headers(cors),'Access-Control-Allow-Methods':'GET, OPTIONS','Access-Control-Allow-Headers':'Content-Type'}});
 if(request.method!=='GET')return respond({error:'Yalnızca GET desteklenir.'},405);
 const url=new URL(request.url),count=Number(env.SHARDS||16);
 if(url.pathname==='/health')return respond({service:'Piyaso music',source:'MusicBrainz CC0',shards:count,scope:'catalogue metadata only'});
 if(url.pathname!=='/search'&&url.pathname!=='/api/music/search')return respond({error:'Arama: /search?q=şarkı'},404);
 const q=(url.searchParams.get('q')||'').trim();
 if(q.length<2||q.length>100)return respond({error:'2–100 karakterlik şarkı veya sanatçı adı yaz.'},400);
 const terms=normalize(q).split(' ').filter(Boolean).slice(0,8);
 if(!terms.length)return respond({songs:[]});
 const key=new Request(url.origin+'/search?q='+encodeURIComponent(terms.join(' ')));
 const cache=globalThis.caches?.default,hit=cache&&await cache.match(key);
 if(hit){const result=new Response(hit.body,hit);for(const [k,v] of Object.entries(headers(cors)))result.headers.set(k,v);return result;}
 const match=terms.map(t=>'"'+t+'"*').join(' AND ');
 try{
 const batches=await Promise.all(Array.from({length:count},(_,i)=>{
  const db=env['MUSIC_'+i];if(!db)throw Error('Eksik veritabanı bağlantısı');
  return db.prepare('SELECT t.id,t.title,t.artist,t.spotify,bm25(tracks_fts) AS rank FROM tracks_fts JOIN tracks t ON t.rowid=tracks_fts.rowid WHERE tracks_fts MATCH ? ORDER BY rank LIMIT 20').bind(match).all();
 }));
 const seen=new Set(),rows=batches.flatMap(b=>b.results||[]).sort((a,b)=>a.rank-b.rank||a.id.localeCompare(b.id)).filter(r=>{if(seen.has(r.id))return false;seen.add(r.id);return true;}).slice(0,20);
 const response=respond({source:'musicbrainz',songs:rows.map(song),attribution:'MusicBrainz core data (CC0)',coverage:'MusicBrainz kapsamı; tüm Spotify kataloğu değildir.'});
 response.headers.set('Cache-Control','public, max-age=300');if(cache)ctx.waitUntil(cache.put(key,response.clone()));return response;
 }catch(e){console.error('Catalogue search failed',e.message);return respond({error:'Katalog hazır değil veya arama geçici olarak kullanılamıyor.'},503);}
}};
