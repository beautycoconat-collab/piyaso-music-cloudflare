# Piyaso — MusicBrainz kataloğunu Cloudflare'a kurma

Bu ZIP bir KURULUM PAKETİDİR. Hazır, tüm şarkılarla dolu katalog değildir. Kurulum bilgisayarında resmî arşivleri indirir, katalog verisini hazırlar ve kendi Cloudflare hesabına yükler. Arşivlerin tamamı bu ZIP'in içine konulmamıştır. Cloudflare'a ZIP'i sürükleyerek veya R2'ye koyarak kurulum yapılmaz.

## Ne gerekiyor?

- Windows, macOS veya Linux bilgisayar. iPhone/iPad Dosyalar uygulamasından doğrudan çalıştırılamaz.
- Node.js 22 veya üzeri: https://nodejs.org/
- Python 3.11 veya üzeri: https://www.python.org/downloads/ (Windows'ta “Add Python to PATH” seçeneğini aç).
- Cloudflare hesabında Workers Paid / D1 erişimi. Sadece başka bir Cloudflare ürününün ücretli olması Workers planının da ücretli olduğu anlamına gelmez.
- Büyük indirme için stabil internet, tercihen 8 GB+ RAM ve en az 150 GB boş disk alanı. Gerçek ihtiyaç güncel arşiv büyüklüğüne göre değişir. İşlem uzun sürebilir; bilgisayarı açık tut.

## Kurulum

1. ZIP'i indir ve bir klasöre tamamen çıkar. ZIP'in içinden çalıştırma.
2. `package.json` dosyasının bulunduğu klasörde Terminal / PowerShell aç.
3. Şunu çalıştır:

```sh
npm install
npm run setup
```

4. Açılan Cloudflare giriş sayfasında kendi hesabına giriş yap ve Wrangler yetkilendirmesini tamamla. Şifreni ChatGPT'ye gönderme. Birden fazla hesabın varsa doğru hesabı seç. Gerekirse terminalde `CLOUDFLARE_ACCOUNT_ID` ortam değişkenini hedef hesap kimliğine ayarla.
5. Kurulum resmî MusicBrainz `LATEST` snapshot'ını sabitler, `release.tar.xz` ve `recording.tar.xz` dosyalarını indirir, SHA256 değerlerini resmî listeyle doğrular. `release` dosyası özellikle büyüktür. Yalnızca `recording` arşivini kullanmak kataloğun çoğunu atlar.
6. Yalnızca gereken temel alanları ayırır ve kayıt kimliğine göre tekrarları birleştirir. Yeni, rastgele isimli 16 D1 veritabanı oluşturur; her birine arama indeksiyle yükler. Bunlar mevcut uygulama veritabanından ayrıdır. 16 parça, D1'in veritabanı başına boyut sınırına karşı planlanan dağılımdır; gelecekteki katalog büyümesine göre yeniden boyutlandırma gerekebilir.
7. Arama servisini Worker olarak yayınlar. Sonda `https://piyaso-music-....workers.dev` adresi çıkar. Bu adresi kopyala.
8. Tarayıcıda önce `ADRES/health`, ardından `ADRES/search?q=Tarkan` aç. Gerçek katalog sonucu gelmesini doğrula. Doğrudan Spotify bağlantısı yoksa sonuçtaki `linkType` değeri `search` olur.
9. Worker adresini ChatGPT'ye gönder. Mevcut Piyaso uygulamasındaki katalog aramasını bu adrese ayrıca bağlamak gerekir; paket mevcut siteyi kendiliğinden değiştirmez.

## Yarıda durursa

Aynı klasörde tekrar `npm run setup` çalıştır. `.setup.json` ve `work` klasörünü koru. Başarılı SQL parçaları hash'leriyle işaretlenir; tamamlanmamış parçalar yeniden çalıştırılabilir. Aynı kaydın tekrar yüklenmesi kopya şarkı üretmez. İndirme devamı, sunucu HTTP Range destekliyorsa `.part` dosyasından sürer. Hata mesajını paylaşabilirsin; şifre veya erişim anahtarı paylaşma.

Hesabı değiştirmeden bu kurulumu tamamla. Aynı `.setup.json` ile farklı hesaba devam etme.

## Güncelleme

Bu paket saatlik ücretli canlı veri akışını kullanmaz. Kurulum anındaki snapshot kullanılır. Yeni snapshot için yeni bir klasörde kurulum yap; test edilen yeni Worker adresine uygulamayı taşı. Böylece eski servis güncelleme sırasında çalışmaya devam eder. Eski kaynakları doğrulamadan silme. Eski snapshot silinmediği sürece depolama ücreti devam eder.

## API ve Piyaso entegrasyonu

`GET /search?q=şarkı%20sanatçı` veya `GET /api/music/search?q=...`

- 2–100 karakter; kelime başlangıcı eşleşmesi, en fazla 20 sonuç. Türkçe karakterler arama için normalize edilir.
- `songs[].id`: MusicBrainz recording kimliği; Spotify kimliği değildir.
- `songs[].source`: `musicbrainz`.
- `songs[].title`, `artist`, `url`, `linkType`, `buttonLabel`, `musicbrainzUrl`.
- `linkType=track`: Kaynakta doğrulanmış biçime sahip bir Spotify parça bağlantısı vardır. Güncelliği veya bölgesel dinlenebilirliği garanti edilmez.
- `linkType=search`: Doğrudan parça bağlantısı yoktur; Spotify'da şarkı/sanatçı araması açılır. Bunu “Spotify'da bul” olarak göster; doğrudan şarkı oynatma diye sunma.
- Kapak resmi, ses dosyası, önizleme veya şarkı sözleri pakete alınmaz.
- Mevcut Piyaso Spotify kimlik doğrulayıcısı 22 karakterlik Spotify ID bekler. Bu cevaplar ona doğrudan takılamaz; uygulama tarafında MusicBrainz kaynağı ve hediye veri modeli için uyarlama gerekir.
- `wrangler.json` içindeki `ALLOWED_ORIGINS` şu an mevcut Piyaso site adresidir. Yeni web alan adlarını virgülle ekleyip `npx wrangler deploy` çalıştır. Native uygulamalar Origin başlığı göndermeyebilir.
- Bu salt okunur servis, katalog arama katmanıdır. Hediye gönderme/kullanıcı hesabı işlemleri Piyaso'nun mevcut backend'inde kalır.

## Kullanım ve maliyet

MusicBrainz verisi Spotify'ın bütün kataloğu değildir. Her kayıt için doğrudan Spotify bağlantısı bulunmaz. Bazı kayıtlar Spotify'da olmayabilir. Spotify bağlantısı hesap açmaz; alıcı kendi hesabında dinler. Tam dinleme ve uygulamanın açılması Spotify'ın kurallarına ve cihazdaki kurulumuna bağlıdır.

Katalog lisans ücretiyle Cloudflare giderleri farklıdır. D1 depolama, satır okumaları/yazmaları ve Workers kullanımı hesabına ücret yansıtabilir. Her arama 16 veritabanında indeks sorgusu yapar; indeksler ve 5 dakikalık edge cache yükü azaltır. Tam ilk aktarım önemli miktarda yazma işlemi üretir. Cloudflare'da kullanım/bütçe uyarıları tanımla. CORS erişim kontrolü kötüye kullanıma karşı kimlik doğrulama veya hız sınırı değildir; yaygın kullanıma açarken Worker alan adında Cloudflare hız sınırlaması/WAF veya uygulama oturum doğrulaması eklenmelidir.

## Lisans ve kaynaklar

Aktarıcı yalnızca CC0 temel alanları saklar: recording kimliği, başlık, sanatçı adları ve recording seviyesindeki Spotify URL ilişkisi. Etiket, puan, açıklama, hazır arama indeksi veya düzenleme geçmişi aktarmaz. Arama indeksini bu alanlardan kendisi oluşturur. Album URL'si yanlışlıkla parça URL'si gibi kullanılmaz. Albüm bağlantılarından parça bağlantısı türetilmez.

MusicBrainz temel verisi CC0: https://musicbrainz.org/doc/About/Data_License
Kapsam: https://musicbrainz.org/doc/MusicBrainz_Database
JSON arşiv yapısı: https://musicbrainz.org/doc/Development/JSON_Data_Dumps
Resmî indirmeler: https://ftp.musicbrainz.org/pub/musicbrainz/data/json-dumps/
Ticari temel veri kullanımı / destek talebi: https://metabrainz.org/datasets/postgres-dumps
Cloudflare D1 import: https://developers.cloudflare.com/d1/best-practices/import-export-data/
Cloudflare D1 sınırları: https://developers.cloudflare.com/d1/platform/limits/
Cloudflare D1 ücretleri: https://developers.cloudflare.com/d1/platform/pricing/

MetaBrainz ticari kullanıcılardan finansal destek istiyor; CC0 temel verinin ticari kullanımına izin verdiğini de açıkça belirtiyor.

## Doğrulama durumu

Yerel otomatik testler: kayıt ayrıştırma, release içindeki kayıtları dahil etme, tekrar yükleme güvenliği, FTS indeks güncellemesi, Türkçe arama, sorgu parametre bağlama ve Spotify track/search ayrımı doğrulandı.

Bu teslimde Cloudflare hesabına giriş yapılmadı, ücretli kaynak oluşturulmadı, tam resmî snapshot indirilmedi ve gerçek hesapta uçtan uca aktarım çalıştırılmadı. Paket kurulum aracıdır; hazır aktarılmış katalog diye sunulmaz.
